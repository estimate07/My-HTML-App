package com.mytool.wrapper

import android.content.Context
import java.io.File

/** Deletes old temp/share files roughly once a day to prevent app bloat. */
object CacheCleaner {
    private const val ONE_DAY = 24 * 60 * 60 * 1000L

    fun maybeClean(ctx: Context) {
        val now = System.currentTimeMillis()
        if (now - Prefs.getLastClean(ctx) < ONE_DAY) return
        Prefs.setLastClean(ctx, now)

        val shareDir = File(ctx.cacheDir, "share")
        if (shareDir.exists()) {
            shareDir.listFiles()?.forEach { f ->
                if (now - f.lastModified() > ONE_DAY) f.delete()
            }
        }
    }
}
