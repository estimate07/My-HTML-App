package com.mytool.wrapper

import android.content.Context

/**
 * Small wrapper over SharedPreferences for values that must survive
 * app restarts AND app updates (onboarding flag, theme, zoom, etc.).
 */
object Prefs {
    private const val FILE = "appwrap_prefs"

    // schema version protects saved data across app updates
    private const val KEY_SCHEMA = "schema_version"
    private const val CURRENT_SCHEMA = 1

    private const val KEY_ONBOARD = "onboarding_done"
    private const val KEY_DARK = "dark_mode"
    private const val KEY_CONTRAST = "high_contrast"
    private const val KEY_ZOOM = "text_zoom"
    private const val KEY_LAST_CHECK = "last_update_check"
    private const val KEY_LAST_CLEAN = "last_cache_clean"

    private fun p(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun ensureSchema(ctx: Context) {
        val v = p(ctx).getInt(KEY_SCHEMA, 0)
        if (v < CURRENT_SCHEMA) {
            // future migrations go here; never wipe user data
            p(ctx).edit().putInt(KEY_SCHEMA, CURRENT_SCHEMA).apply()
        }
    }

    fun onboardingDone(ctx: Context) = p(ctx).getBoolean(KEY_ONBOARD, false)
    fun setOnboardingDone(ctx: Context) = p(ctx).edit().putBoolean(KEY_ONBOARD, true).apply()

    fun isDark(ctx: Context) = p(ctx).getBoolean(KEY_DARK, false)
    fun setDark(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean(KEY_DARK, on).apply()

    fun isHighContrast(ctx: Context) = p(ctx).getBoolean(KEY_CONTRAST, false)
    fun setHighContrast(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean(KEY_CONTRAST, on).apply()

    fun getTextZoom(ctx: Context) = p(ctx).getInt(KEY_ZOOM, 100)
    fun setTextZoom(ctx: Context, percent: Int) = p(ctx).edit().putInt(KEY_ZOOM, percent).apply()

    fun getLastCheck(ctx: Context) = p(ctx).getLong(KEY_LAST_CHECK, 0L)
    fun setLastCheck(ctx: Context, t: Long) = p(ctx).edit().putLong(KEY_LAST_CHECK, t).apply()

    fun getLastClean(ctx: Context) = p(ctx).getLong(KEY_LAST_CLEAN, 0L)
    fun setLastClean(ctx: Context, t: Long) = p(ctx).edit().putLong(KEY_LAST_CLEAN, t).apply()
}
