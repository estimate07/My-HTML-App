package com.mytool.wrapper

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream

/**
 * Everything here is callable from the web tool as:  window.Native.methodName(...)
 * All @JavascriptInterface methods run on a background WebView thread.
 */
class NativeBridge(private val activity: MainActivity, private val web: WebView) {

    private val ctx: Context get() = activity.applicationContext

    // ---------- FILE SAVE / EXPORT ----------

    /** Save text into app-specific files dir. Returns the file path. */
    @JavascriptInterface
    fun saveFile(name: String, content: String): String {
        val dir = File(ctx.filesDir, "exports").apply { mkdirs() }
        val f = File(dir, safe(name))
        f.writeText(content)
        toast("Saved: ${f.name}")
        return f.absolutePath
    }

    /** Save + compress (deflate) to shrink storage use. Adds .z extension. */
    @JavascriptInterface
    fun saveFileCompressed(name: String, content: String): String {
        val dir = File(ctx.filesDir, "exports").apply { mkdirs() }
        val f = File(dir, safe(name) + ".z")
        DeflaterOutputStream(f.outputStream(), Deflater(Deflater.BEST_COMPRESSION)).use {
            it.write(content.toByteArray())
        }
        return f.absolutePath
    }

    /** Read back a compressed file saved above. */
    @JavascriptInterface
    fun readFileCompressed(path: String): String {
        return InflaterInputStream(File(path).inputStream()).bufferedReader().use { it.readText() }
    }

    // ---------- SHARE ----------

    /** Native share sheet (WhatsApp, email, Drive...) for a text file. */
    @JavascriptInterface
    fun shareText(name: String, content: String) {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, safe(name))
        f.writeText(content)
        shareFilePath(f.absolutePath)
    }

    /** Share an already-saved file by its path. */
    @JavascriptInterface
    fun shareFilePath(path: String) {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Batch export: names[] and contents[] as JSON arrays, shares all at once. */
    @JavascriptInterface
    fun shareMany(namesJson: String, contentsJson: String) {
        val names = org.json.JSONArray(namesJson)
        val contents = org.json.JSONArray(contentsJson)
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val uris = ArrayList<android.net.Uri>()
        for (i in 0 until names.length()) {
            val f = File(dir, safe(names.getString(i)))
            f.writeText(contents.getString(i))
            uris.add(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f))
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(intent, "Export all").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- CLIPBOARD ----------

    @JavascriptInterface
    fun copyToClipboard(text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("app", text))
    }

    @JavascriptInterface
    fun readClipboard(): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
    }

    // ---------- SETTINGS THAT PERSIST ACROSS RESTART ----------

    @JavascriptInterface
    fun setDark(on: Boolean) = Prefs.setDark(ctx, on)

    @JavascriptInterface
    fun isDark(): Boolean = Prefs.isDark(ctx)

    @JavascriptInterface
    fun setHighContrast(on: Boolean) = Prefs.setHighContrast(ctx, on)

    @JavascriptInterface
    fun isHighContrast(): Boolean = Prefs.isHighContrast(ctx)

    /** Persist text zoom (percentage, e.g. 100). Applied on next launch too. */
    @JavascriptInterface
    fun setTextZoom(percent: Int) {
        Prefs.setTextZoom(ctx, percent)
        web.post { web.settings.textZoom = percent }
    }

    // ---------- DEBUG INFO ----------

    @JavascriptInterface
    fun debugInfo(): String {
        val storage = folderSize(ctx.filesDir) + folderSize(ctx.cacheDir)
        val obj = org.json.JSONObject()
        obj.put("versionName", pkgVersionName())
        obj.put("bundledVersion", MainActivity.BUNDLED_VERSION)
        obj.put("storageBytes", storage)
        obj.put("lastUpdateCheck", Prefs.getLastCheck(ctx))
        return obj.toString()
    }

    // ---------- helpers ----------

    private fun safe(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun toast(msg: String) = web.post {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    private fun pkgVersionName(): String =
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"

    private fun folderSize(dir: File): Long =
        dir.walkTopDown().filter { it.isFile }.map { it.length() }.sum()
}
