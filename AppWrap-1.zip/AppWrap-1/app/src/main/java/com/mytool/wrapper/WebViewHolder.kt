package com.mytool.wrapper

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebView

/**
 * Holds a single WebView in memory so re-opening the app is instant
 * and does not reload from scratch each time.
 */
object WebViewHolder {
    @SuppressLint("StaticFieldLeak")
    private var web: WebView? = null

    fun get(appContext: Context): WebView {
        if (web == null) {
            web = WebView(appContext)
        }
        return web!!
    }

    fun peek(): WebView? = web
}
