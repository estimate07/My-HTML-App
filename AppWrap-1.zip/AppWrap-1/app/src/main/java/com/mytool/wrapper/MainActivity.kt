package com.mytool.wrapper

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var container: FrameLayout
    private lateinit var statusDot: TextView
    private lateinit var bridge: NativeBridge

    private var filePickerCallback: ValueCallback<Array<Uri>>? = null

    // Native "Choose file" picker for <input type=file> in the web tool
    private val filePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePickerCallback?.onReceiveValue(uris)
            filePickerCallback = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Drop the splash theme back to the normal app theme
        setTheme(R.style.Theme_AppWrap)
        setContentView(R.layout.activity_main)

        Prefs.ensureSchema(this)

        container = findViewById(R.id.web_container)
        statusDot = findViewById(R.id.status_dot)

        // Hidden debug menu via app-icon shortcut
        if (intent?.getBooleanExtra("debug", false) == true) showDebugMenu()

        // FAST OPEN: reuse a cached WebView instead of building a new one every launch
        val web = WebViewHolder.get(applicationContext)
        (web.parent as? ViewGroup)?.removeView(web)
        container.addView(
            web,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        configureWebView(web)

        bridge = NativeBridge(this, web)
        web.addJavascriptInterface(bridge, "Native")

        updateConnectionDot()
        showOnboardingOnce()

        // Decide bundled vs remote, then load
        loadCorrectSource(web)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(web: WebView) {
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage persistence
            databaseEnabled = true            // IndexedDB persistence
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            // Text size / zoom persistence is restored from prefs
            textZoom = Prefs.getTextZoom(this@MainActivity)
            builtInZoomControls = true
            displayZoomControls = false
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Push saved dark-mode + high-contrast flags into the web tool
                val dark = Prefs.isDark(this@MainActivity)
                val contrast = Prefs.isHighContrast(this@MainActivity)
                view?.evaluateJavascript(
                    "window.__NATIVE_THEME__ && window.__NATIVE_THEME__($dark,$contrast);",
                    null
                )
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePickerCallback?.onReceiveValue(null)
                filePickerCallback = callback
                return try {
                    filePicker.launch(params?.createIntent())
                    true
                } catch (e: Exception) {
                    filePickerCallback = null
                    false
                }
            }
        }
    }

    private fun loadCorrectSource(web: WebView) {
        // Default = offline bundled file
        val bundled = "file:///android_asset/index.html"

        if (!isOnline()) {
            web.loadUrl(bundled)
            return
        }

        // Online: check version endpoint in background, fall back silently on any failure
        thread {
            val remoteUrl = try {
                val text = URL(VERSION_ENDPOINT).readTextSafe()
                val json = JSONObject(text)
                val remoteVersion = json.optInt("version", -1)
                val hostedUrl = json.optString("url", "")
                if (remoteVersion > BUNDLED_VERSION && hostedUrl.isNotBlank()) hostedUrl else null
            } catch (e: Exception) {
                null
            }

            Prefs.setLastCheck(this, System.currentTimeMillis())
            runOnUiThread {
                web.loadUrl(remoteUrl ?: bundled)
            }
        }
    }

    private fun URL.readTextSafe(): String {
        val conn = openConnection() as HttpURLConnection
        conn.connectTimeout = 4000
        conn.readTimeout = 4000
        conn.inputStream.bufferedReader().use { return it.readText() }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(net) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun updateConnectionDot() {
        val online = isOnline()
        statusDot.text = if (online) "● online" else "● offline"
        statusDot.setTextColor(if (online) 0xFF34C759.toInt() else 0xFF8E8E93.toInt())
    }

    private fun showOnboardingOnce() {
        if (Prefs.onboardingDone(this)) return
        Prefs.setOnboardingDone(this)   // mark immediately so it never shows twice
        AlertDialog.Builder(this)
            .setTitle("Welcome")
            .setMessage(
                "This app runs your tool fully offline.\n\n" +
                    "• Your projects auto-save on this phone.\n" +
                    "• Use the Share button to send files out.\n" +
                    "• A small dot shows online/offline status.\n\n" +
                    "That's it — start creating."
            )
            .setPositiveButton("Got it", null)
            .setCancelable(false)
            .show()
    }

    private fun showDebugMenu() {
        val storage = (filesDir.walkTopDown().filter { it.isFile }.map { it.length() }.sum()) / 1024
        val last = Prefs.getLastCheck(this)
        AlertDialog.Builder(this)
            .setTitle("Debug")
            .setMessage(
                "Version: ${MainActivity.BUNDLED_VERSION}\n" +
                    "Storage used: ${storage} KB\n" +
                    "Last update check: ${if (last == 0L) "never" else java.util.Date(last)}"
            )
            .setPositiveButton("Close", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        updateConnectionDot()
        CacheCleaner.maybeClean(this)   // periodic cache cleanup
    }

    override fun onDestroy() {
        // Keep the cached WebView alive for fast re-open; just detach it
        (WebViewHolder.peek()?.parent as? ViewGroup)?.removeView(WebViewHolder.peek())
        super.onDestroy()
    }

    override fun onBackPressed() {
        val web = WebViewHolder.peek()
        if (web != null && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    companion object {
        // ==== EDIT THESE FOR FUTURE HOSTED UPDATES ====
        const val BUNDLED_VERSION = 1
        const val VERSION_ENDPOINT = "https://example.com/version.json"
    }
}
