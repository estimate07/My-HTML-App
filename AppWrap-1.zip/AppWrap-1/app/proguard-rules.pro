# Keep the JavaScript bridge class and its @JavascriptInterface methods
-keepclassmembers class com.mytool.wrapper.NativeBridge {
    public *;
}
-keepattributes JavascriptInterface
